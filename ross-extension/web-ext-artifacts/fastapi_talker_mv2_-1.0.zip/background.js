// Can be empty; Firefox just wants a background script in MV2.
console.log("FastAPI Talker background ready");
